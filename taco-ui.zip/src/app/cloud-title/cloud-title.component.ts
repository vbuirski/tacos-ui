import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-title',
  templateUrl: './cloud-title.component.html',
  styleUrls: ['./cloud-title.component.css']
})
export class CloudTitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
