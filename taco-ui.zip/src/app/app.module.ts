import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { CloudTitleComponent } from './cloud-title/cloud-title.component';
import { RecentsComponent } from './recents/recents.component';
import { NonWrapsPipe } from './recents/NonWrapsPipe';
import { WrapsPipe } from './recents/WrapsPipe';
import { LittleButtonComponent } from './little-button/little-button.component';
import { DesignComponent } from './design/design.component';
import { CartComponent } from './cart/cart.component';
import { BigButtonComponent } from './big-button/big-button.component';
import { GroupBoxComponent } from './group-box/group-box.component';
import { CartService } from './cart/cart-service';
import { RecentTacosService } from './recents/RecentTacosService';
import { ApiService } from './api/ApiService';
import { LoginComponent } from './login/login.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    CloudTitleComponent,
    RecentsComponent,
    NonWrapsPipe,
    WrapsPipe,
    LittleButtonComponent,
    DesignComponent,
    CartComponent,
    BigButtonComponent,
    GroupBoxComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
              ApiService,
              CartService,
              RecentTacosService],
  bootstrap: [AppComponent]
})
export class AppModule { }

