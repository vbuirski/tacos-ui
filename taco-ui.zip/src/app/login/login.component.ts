import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router/';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model = {
    username: '',
    password: ''
  };

  response: any;

  constructor(private httpClient: HttpClient, private router: Router) { }

  ngOnInit(): void {
  }

  update(username: string, password: string) {
    this.model.username = username;
    this.model.password = password;
  }

  onSubmit() {
    let headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'});
    let options = { headers: headers };
        this.httpClient.post(
            'http://localhost:8080/login',
            this.model, options).subscribe(data => this.response = data);

    this.router.navigate(['/home']);
  }


}
